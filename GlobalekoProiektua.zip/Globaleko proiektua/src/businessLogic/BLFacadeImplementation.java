package businessLogic;

import java.util.Collection;


import javax.jws.WebMethod;
import javax.jws.WebService;

import configuration.ConfigXML;
import dataAccess.DataAccess;
import domain.Bezero;
import domain.Dibisa;
import domain.Kontua;
import domain.Sukurtsal;

/**
 * It implements the business logic as a web service.
 */
@WebService(endpointInterface = "businessLogic.BLFacade")
public class BLFacadeImplementation  implements BLFacade {

	public BLFacadeImplementation()  {		
		System.out.println("Creating BLFacadeImplementation instance");
		ConfigXML c=ConfigXML.getInstance();
		
		if (c.getDataBaseOpenMode().equals("initialize")) {
			DataAccess dbManager=new DataAccess(c.getDataBaseOpenMode().equals("initialize"));
			dbManager.initializeDB();
			dbManager.close();
			}
		
	}


	@Override
	public void initializeBD() {
		
	}

	@Override
	public Bezero getUser(String nan) {
		DataAccess dB=new DataAccess();
		return dB.getUser(nan);
	}

	@WebMethod
	public Collection<Sukurtsal> getSukurtsalak(){
		DataAccess dB = new DataAccess();
		return dB.getSukurtsalak();
		
	}
	@WebMethod
	public Collection<Dibisa> getDibisak(){
		DataAccess dB = new DataAccess();
		return dB.getDibisak();
		
	}

	@WebMethod
	public void dibisaSaldu(Integer kontID, Integer sukurID, String mota, float kop){
		DataAccess dB = new DataAccess();
		dB.dibisaSaldu(kontID, sukurID, mota, kop);
		
	}
	@WebMethod
	public int dibisaErosi(Integer kontID, Integer sukurID, String mota, float kop){
		DataAccess dB = new DataAccess();
		return dB.dibisaErosi(kontID, sukurID, mota, kop);
		
	}


	
	

}

